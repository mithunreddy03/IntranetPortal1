import React from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {
  FaHome,
  FaBell,
  FaSearch,
  FaUser,
  FaClipboardList,
  FaChartBar,
  FaCalendarAlt,
} from "react-icons/fa";
import "../pages/style.css";

const Home = () => {
  return (
    <div className="home-main-container">
      {/* Sidebar */}
      <div className="nav-container">
        <div className="logo">
          <img src="/mahindra-university-logo.png" alt="Mahindra University Logo" />
        </div>
        <div className="nav-item">
          <FaHome className="icon" />
          <span>Home</span>
        </div>
        <div className="nav-item">
          <FaBell className="icon" />
          <span>Announcements</span>
        </div>
        <div className="nav-item">
          <FaSearch className="icon" />
          <span>Search</span>
        </div>
        <div className="nav-item">
          <FaUser className="icon" />
          <span>Profile</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-container">
        <div className="header">
          <div className="user-info">
            <h2>Tejas</h2>
            <p>Artificial Intelligence B.Tech</p>
          </div>
          {/* <img className="profile-pic" src="/profile-image.png" alt="Profile" /> */}
        </div>

        <div className="black-box">
          <div className="black-box-item">
            <FaClipboardList className="black-box-icon" />
            <span>Attendance</span>
          </div>
          <div className="black-box-item">
            <FaChartBar className="black-box-icon" />
            <span>Statistics</span>
          </div>
          <div className="black-box-item">
            <FaCalendarAlt className="black-box-icon" />
            <span>Scheduler</span>
          </div>
        </div>

        <div className="grid-container">
          {[  
            { name: "Clubs", img: "icons8-user-groups-48.png" },
            { name: "Courses", img: "icons8-courses-64.png" },
            { name: "Slot Booking", img: "/icons8-ticket-purchase-48.png" },
            { name: "Mail", img: "/icons8-mail-48.png" },
            { name: "Complaint", img: "icons8-complaint-100.png" },
            { name: "Hostel", img: "icons8-hostel-64.png" },
            { name: "Feedback", img: "icons8-feedback-60.png" },
            { name: "More", img: "/icons8-application-32.png" },
          ].map((item, index) => (
            <div className="grid-item" key={index}>
              <img src={item.img} alt={item.name} className="grid-icon" />
              <span>{item.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
