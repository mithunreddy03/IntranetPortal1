import React from "react";
import { Link } from "react-router-dom";

const Announcements = () => {
  return (
    <div>
      <h1>Announcements Page</h1>
      <p>This is where announcements will be displayed.</p>
      <Link to="/">Back to Home</Link>
    </div>
  );
};

export default Announcements;
