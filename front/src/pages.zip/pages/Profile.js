import React from "react";
import { Link } from "react-router-dom";

const Profile = () => {
  return (
    <div>
      <h1>Profile Page</h1>
      <p>View and edit your profile here.</p>
      <Link to="/">Back to Home</Link>
    </div>
  );
};

export default Profile;
