import React from "react";
import { Link } from "react-router-dom";

const Search = () => {
  return (
    <div>
      <h1>Search Page</h1>
      <p>Search for courses, clubs, and more!</p>
      <Link to="/">Back to Home</Link>
    </div>
  );
};

export default Search;
